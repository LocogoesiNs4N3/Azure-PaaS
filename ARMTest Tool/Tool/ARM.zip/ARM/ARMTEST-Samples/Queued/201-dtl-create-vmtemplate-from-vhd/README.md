# Create a new VM template from a VHD.

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fazure%2Fazure-quickstart-templates%2Fmaster%2F201-dtl-create-vmtemplate-from-vhd%2Fazuredeploy.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>

<a href="http://armviz.io/#/?load=https://raw.githubusercontent.com/azure/azure-quickstart-templates/master/201-dtl-create-vmtemplate-from-vhd/azuredeploy.json" target="_blank">
  <img src="http://armviz.io/visualizebutton.png"/>
</a>


This deployment template is used to create a VM template from an existing VHD in the lab.
- The VM template will be created in the same lab in which the VHD exists.
