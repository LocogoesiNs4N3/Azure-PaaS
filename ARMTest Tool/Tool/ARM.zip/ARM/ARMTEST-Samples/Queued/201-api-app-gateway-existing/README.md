# Provision an API app with an existing gateway

For information about using this template, see [Provision an API app with an existing gateway](https://azure.microsoft.com/en-us/documentation/articles/app-service-api-arm-existing-gateway-provision/).