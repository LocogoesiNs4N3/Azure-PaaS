# Install updates
sudo apt-get -y update

#Install Mongo DB
sudo apt-get install -y mongodb-10gen
