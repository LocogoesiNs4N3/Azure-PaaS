# Create a Logic App plus API app using a template

For information about using this template, see [Create a Logic App plus API app using a template](https://azure.microsoft.com/en-us/documentation/articles/app-service-logic-arm-with-api-app-provision/).
