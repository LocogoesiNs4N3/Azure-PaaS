# Deploy a Windows VM and execute a custom PowerShell script.

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Ftcsatheesh%2Fazure-quickstart-templates%2Fmaster%2Fwindows-vm-custom-script%2Fazuredeploy.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>

Based on the 101-simple-windows-vm template built by: [coreysa](https://github.com/coreysa)

This template allows you to deploy a simple Windows VM and execute a custom powershell script using the custom script extension. Note the script must be in stored in a azure blob storage.
