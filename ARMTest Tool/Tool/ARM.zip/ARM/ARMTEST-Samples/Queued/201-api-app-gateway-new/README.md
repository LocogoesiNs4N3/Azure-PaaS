# Provision an API app with a new gateway

For information about using this template, see [Provision an API app with a new gateway](https://azure.microsoft.com/en-us/documentation/articles/app-service-api-arm-new-gateway-provision/).
