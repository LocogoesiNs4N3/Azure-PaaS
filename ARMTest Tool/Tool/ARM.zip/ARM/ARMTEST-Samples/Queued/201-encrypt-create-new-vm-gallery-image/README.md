# Create a new encrypted windows vm from gallery image. 

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Fazure%2Fazure-quickstart-templates%2Fmaster%2F201-encrypt-create-new-vm-gallery-image%2Fazuredeploy.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>

This template creates a new encrypted windows vm using the server 2k12 gallery image. It internally calls the "201-encrypt-running-windows-vm" template.