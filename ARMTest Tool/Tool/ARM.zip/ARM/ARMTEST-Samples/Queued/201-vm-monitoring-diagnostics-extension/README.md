<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FAzure%2Fazure-quickstart-templates%2Fmaster%2F201-vm-monitoring-diagnostics-extension%2Fazuredeploy.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>

This template deploys a Windows VM along with the diagnostics extension. For more information on the diagnostics configuration see [Azure Diagnostics Extension in a resource manager template](http://azure.microsoft.com/documentation/articles/virtual-machines-extensions-diagnostics-windows-template). 

