# Starter template with validation

This is a starter template that will pass the validation checks. Please read the [contribution guide](https://github.com/Azure/azure-quickstart-templates#contribution-guide) to learn more about what's required for successfully passing validation checks. 

In this example, the template deploys a basic Availability Set resource. This is just a snippet you may want to include in a more complex template.
