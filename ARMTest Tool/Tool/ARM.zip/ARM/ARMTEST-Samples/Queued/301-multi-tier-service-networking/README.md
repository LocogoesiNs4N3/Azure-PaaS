This template showcases a simple 3 tier service with L7 load balancers in the Front end, Application servers in the middle tier and SQL data bases in the backend. The subnets are secured using Network Security Groups and databases are placed behind Internal load balancer.

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fgithub.com%2FAzure%2Fazure-quickstart-templates%2Fraw%2Fmaster%2F301-multi-tier-service-networking%2Fazuredeploy.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>