# Discover Private IP dynamically

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FAzure%2Fazure-quickstart-templates%2Fmaster%2F201-discover-private-ip-dynamically%2Fazuredeploy.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>

This template allows you to discover a private IP for a NIC dynamically. It passes the private IP of NIC0 to VM1 using custom script extensions which writes it to a file on VM1.
