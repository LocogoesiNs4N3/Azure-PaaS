# Create a Redis Cache using a template

For information about using this template, see [Create a Redis Cache using a template](https://azure.microsoft.com/en-us/documentation/articles/cache-redis-cache-arm-provision/).

